package net.mcreator.minecraftenhanced.procedures;

import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.minecraftenhanced.potion.BleedingPotion;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;
import net.mcreator.minecraftenhanced.MinecraftEnhancedMod;

import java.util.Map;

@MinecraftEnhancedModElements.ModElement.Tag
public class AdministerTheBleedingProcedure extends MinecraftEnhancedModElements.ModElement {
	public AdministerTheBleedingProcedure(MinecraftEnhancedModElements instance) {
		super(instance, 46);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency entity for procedure AdministerTheBleeding!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(BleedingPotion.potion, (int) 60, (int) 0, (false), (false)));
	}
}
