package net.mcreator.minecraftenhanced.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;
import net.mcreator.minecraftenhanced.MinecraftEnhancedMod;

import java.util.Map;

@MinecraftEnhancedModElements.ModElement.Tag
public class BurnedObsidianBurningProcedure extends MinecraftEnhancedModElements.ModElement {
	public BurnedObsidianBurningProcedure(MinecraftEnhancedModElements instance) {
		super(instance, 62);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency entity for procedure BurnedObsidianBurning!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.attackEntityFrom(DamageSource.ON_FIRE, (float) 0.5);
	}
}
