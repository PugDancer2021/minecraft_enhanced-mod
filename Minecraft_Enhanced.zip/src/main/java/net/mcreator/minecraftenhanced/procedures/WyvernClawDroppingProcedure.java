package net.mcreator.minecraftenhanced.procedures;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.item.ItemEntity;

import net.mcreator.minecraftenhanced.item.WyvernsClawItem;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;
import net.mcreator.minecraftenhanced.MinecraftEnhancedMod;

import java.util.Map;

@MinecraftEnhancedModElements.ModElement.Tag
public class WyvernClawDroppingProcedure extends MinecraftEnhancedModElements.ModElement {
	public WyvernClawDroppingProcedure(MinecraftEnhancedModElements instance) {
		super(instance, 40);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency x for procedure WyvernClawDropping!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency y for procedure WyvernClawDropping!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency z for procedure WyvernClawDropping!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency world for procedure WyvernClawDropping!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		if (world instanceof World && !world.isRemote()) {
			ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack(WyvernsClawItem.block, (int) (1)));
			entityToSpawn.setPickupDelay((int) 10);
			world.addEntity(entityToSpawn);
		}
		if (world instanceof World && !world.isRemote()) {
			ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack(WyvernsClawItem.block, (int) (1)));
			entityToSpawn.setPickupDelay((int) 10);
			world.addEntity(entityToSpawn);
		}
	}
}
