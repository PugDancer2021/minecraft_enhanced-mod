package net.mcreator.minecraftenhanced.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.minecraftenhanced.item.BottleOfBloodItem;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;
import net.mcreator.minecraftenhanced.MinecraftEnhancedMod;

import java.util.Map;

@MinecraftEnhancedModElements.ModElement.Tag
public class DrinkingProcedure extends MinecraftEnhancedModElements.ModElement {
	public DrinkingProcedure(MinecraftEnhancedModElements instance) {
		super(instance, 85);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MinecraftEnhancedMod.LOGGER.warn("Failed to load dependency entity for procedure Drinking!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof PlayerEntity) {
			ItemStack _stktoremove = new ItemStack(BottleOfBloodItem.block, (int) (1));
			((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) 1,
					((PlayerEntity) entity).container.func_234641_j_());
		}
		if (entity instanceof PlayerEntity) {
			ItemStack _setstack = new ItemStack(Items.GLASS_BOTTLE, (int) (1));
			_setstack.setCount((int) 1);
			ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
		}
	}
}
