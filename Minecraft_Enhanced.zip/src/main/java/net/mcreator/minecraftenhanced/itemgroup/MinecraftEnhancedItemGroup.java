
package net.mcreator.minecraftenhanced.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.minecraftenhanced.item.SapphireIngotItem;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;

@MinecraftEnhancedModElements.ModElement.Tag
public class MinecraftEnhancedItemGroup extends MinecraftEnhancedModElements.ModElement {
	public MinecraftEnhancedItemGroup(MinecraftEnhancedModElements instance) {
		super(instance, 22);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabminecraft_enhanced") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(SapphireIngotItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
