
package net.mcreator.minecraftenhanced.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.minecraftenhanced.itemgroup.MinecraftEnhancedItemGroup;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;

import java.util.List;

@MinecraftEnhancedModElements.ModElement.Tag
public class BloodyKnifeItem extends MinecraftEnhancedModElements.ModElement {
	@ObjectHolder("minecraft_enhanced:bloody_knife")
	public static final Item block = null;
	public BloodyKnifeItem(MinecraftEnhancedModElements instance) {
		super(instance, 70);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 125;
			}

			public float getEfficiency() {
				return 6f;
			}

			public float getAttackDamage() {
				return -1f;
			}

			public int getHarvestLevel() {
				return 0;
			}

			public int getEnchantability() {
				return 0;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Items.IRON_INGOT, (int) (1)));
			}
		}, 3, 1.2f, new Item.Properties().group(MinecraftEnhancedItemGroup.tab)) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("Go ahead"));
				list.add(new StringTextComponent("do it again"));
			}
		}.setRegistryName("bloody_knife"));
	}
}
