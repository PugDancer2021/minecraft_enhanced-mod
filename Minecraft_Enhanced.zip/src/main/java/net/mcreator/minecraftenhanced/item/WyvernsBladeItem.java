
package net.mcreator.minecraftenhanced.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.minecraftenhanced.itemgroup.MinecraftEnhancedItemGroup;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;

import java.util.List;

@MinecraftEnhancedModElements.ModElement.Tag
public class WyvernsBladeItem extends MinecraftEnhancedModElements.ModElement {
	@ObjectHolder("minecraft_enhanced:wyverns_blade")
	public static final Item block = null;
	public WyvernsBladeItem(MinecraftEnhancedModElements instance) {
		super(instance, 2);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 2563;
			}

			public float getEfficiency() {
				return 10f;
			}

			public float getAttackDamage() {
				return 61f;
			}

			public int getHarvestLevel() {
				return 0;
			}

			public int getEnchantability() {
				return 21;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 3, -0.3f, new Item.Properties().group(MinecraftEnhancedItemGroup.tab).isImmuneToFire()) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("The Wyvern's most prized possesion"));
			}
		}.setRegistryName("wyverns_blade"));
	}
}
