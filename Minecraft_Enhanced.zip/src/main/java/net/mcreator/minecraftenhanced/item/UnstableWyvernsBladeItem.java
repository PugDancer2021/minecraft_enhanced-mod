
package net.mcreator.minecraftenhanced.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.minecraftenhanced.procedures.StrengthProcedure;
import net.mcreator.minecraftenhanced.procedures.AssasinationProcedure;
import net.mcreator.minecraftenhanced.itemgroup.MinecraftEnhancedItemGroup;
import net.mcreator.minecraftenhanced.MinecraftEnhancedModElements;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

@MinecraftEnhancedModElements.ModElement.Tag
public class UnstableWyvernsBladeItem extends MinecraftEnhancedModElements.ModElement {
	@ObjectHolder("minecraft_enhanced:unstable_wyverns_blade")
	public static final Item block = null;
	public UnstableWyvernsBladeItem(MinecraftEnhancedModElements instance) {
		super(instance, 43);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 5500;
			}

			public float getEfficiency() {
				return 12f;
			}

			public float getAttackDamage() {
				return 121f;
			}

			public int getHarvestLevel() {
				return 0;
			}

			public int getEnchantability() {
				return 75;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(MagmaticObsidianIngotItem.block, (int) (1)));
			}
		}, 3, 4f, new Item.Properties().group(MinecraftEnhancedItemGroup.tab).isImmuneToFire()) {
			@Override
			public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
				super.addInformation(itemstack, world, list, flag);
				list.add(new StringTextComponent("Although it resembles an explosion, this sword willnot combust."));
			}

			@Override
			public boolean hitEntity(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
				boolean retval = super.hitEntity(itemstack, entity, sourceentity);
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				World world = entity.world;
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					AssasinationProcedure.executeProcedure($_dependencies);
				}
				return retval;
			}

			@Override
			public void inventoryTick(ItemStack itemstack, World world, Entity entity, int slot, boolean selected) {
				super.inventoryTick(itemstack, world, entity, slot, selected);
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				if (selected) {
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("entity", entity);
					StrengthProcedure.executeProcedure($_dependencies);
				}
			}
		}.setRegistryName("unstable_wyverns_blade"));
	}
}
